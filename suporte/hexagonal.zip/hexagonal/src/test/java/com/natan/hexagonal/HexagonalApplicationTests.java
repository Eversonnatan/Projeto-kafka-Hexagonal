package com.natan.hexagonal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HexagonalApplicationTests {

	@Test
	void contextLoads() {
	}

}
